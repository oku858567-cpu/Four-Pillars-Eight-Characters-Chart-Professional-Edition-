# 项目进度

## 当前版本 V2.2
上次工作: 2026-05-29

### V2.0 (2026-05-29)
- **运势5段文案唯一性**: 三合一方案（时段副词前缀 + 5变体轮选 + 藏干支附加句），彻底消除同人同日刷新文案重复
- **DIM_SS_TEXT扩展**: 100条→500条（每十神good/bad各5变体），配合seed散列让不同人看到不同变体
- **calcPersonSeed**: 用`(year*3 + month*7 + day*11 + hour*19) % 5`做个性散列，同人同天结果不变，换人则不同
- **20人自动化测试验证**: 流日/大运100%唯一，流月/流年唯一率从45%提升至85%
- **新常量体系**: PERIOD_ADVERB(5时段副词), PERIOD_IDX(时段索引), HIDDEN_SS_NOTE(10十神藏干短评)
- **git push**: 已推送至 GitHub

### V2.2 (2026-05-29)
- **版本更新历史页面** — settings 页新增卡片，展示全部7个版本的中文标注+彩色标签+要点
- **数据驱动** — version-history.js 结构化数据 + settings.js 渲染引擎
- **规则追加**: 版本号更新时同步修改 version-history.js
- **git push**: 已推送至 GitHub

### V2.1 (2026-05-29)
- **择日月历选中日高亮**: 当天保留金色背景 + 选中日红色边框圈，切换日期后红圈跟随
- **吉凶标签修复**: CDN 版 lunar 缺 getDayTwelveDayGod()，改用地支索引推算十二神
- **规则追加**: 每次 git commit 前必须更新版本号（index.html 3处 + progress.md）
- **git push**: 已推送至 GitHub

### V2.0 (2026-05-28)
- **运势维度窜修复**: buildAdvice 全局内容仅 dim==='overall' 时显示，消除"收缩战线"等不相关文案
- **死代码清理**: 删除6个未引用函数(struct+5func)，yunshi.js 从677行减至529行
- **合盘bug修复**: 甲方缺 hp1Name 输入框，readHpInput 静默崩溃；补上 + ?. 可选链防御
- **版本号**: 内测版 V1.0 → V2.0 (index.html 3处)
- **git push**: commit c34ed8a → origin/master
- **迁移**: 项目从桌面移至 E:\bazi
- **GitHub Pages**: 自动部署，访问 https://xiaopang1948.github.io/bazi/

### V2.3 (2026-06-01)
- **子时换日修复**（bazi-engine.js:475-496）：匹配问真八字全子时换日规则
  - 23:00-23:59 夜子时 → 日柱/农历日期进到次日，时柱用库的早晚子时结果
  - 4个边界测试全部通过（主案例/00:05/22:50/23:59）
  - 大运计算未受影响（已使用真太阳校正后的 calcHour/calcMin）
- **测试流程标准化**：写入 memory/bazi-test-flow.md，后续测试按固定路径执行

### 已知未完成
- v4: AI解读 / 紫微斗数 / 云端存储（需后端，暂缓）
- CSS 变量化合并（仍有部分重复颜色定义）
- 新组件命名不一致（pillars.js 用 BaziComponents 命名空间，其余用全局函数）
