const VERSION_HISTORY = [
  {
    version: 'V2.9', label: '内测版', date: '2026-06-09', tag: 'feat',
    items: [
      '全局状态管理迁移 — 所有 localStorage 读写归一至 BaziStore，pub/sub 事件驱动',
      'CSS 样式系统重构 — 19+ 冗余选择器合并，inline 样式→CSS 类迁移',
      '死代码清理 — 移除 wuyun-liuqi/celebrity/daily-score/report 等 6 个未用文件',
      '合盘评分引擎 — 多维合盘评分+仪表盘图+详情表',
      '历史记录增强 — 合盘记录保存、多条件搜索、Clear All',
      '合盘级联选择 — 省→市联动+真太阳时自动填充',
      '全链路缺陷修复 — CSS 变量补齐、夜子时逻辑修正、流年十神算法修复、7+ null guard',
    ],
  },
  {
    version: 'V2.8', label: '内测版', date: '2026-06-03', tag: 'feat',
    items: [
      'AI 小卦助手集成 — 右下角浮动触发，八字数据实时推送至状态栏+System Prompt',
      '拖拽边界约束 — 不可拖出视口，顶部 60px 安全区避开太极图',
      '手机端响应式增强 — touch-action、间距收缩、≤380px 隐藏文字',
      '修复八字显示 bug — pillars.ganzhi → stem+branch 拼接',
    ],
  },
  {
    version: 'V2.7', label: '内测版', date: '2026-06-03', tag: 'ui',
    items: [
      '版本号自动填充 — 左上角/loading/页面标题从version-history.js第一条自动读取',
      'lessons.md 版本号规则更新 — 只需改 version-history.js，无需手动改 HTML',
    ],
  },
  {
    version: 'V2.6', label: '内测版', date: '2026-06-02', tag: 'fix',
    items: [
      '流月节气拼音→中文映射 — 库返回DA_XUE等拼音，加JIE_QI_NAME_MAP转中文显示',
    ],
  },
  {
    version: 'V2.5', label: '内测版', date: '2026-06-02', tag: 'fix',
    items: [
      '流月改为节气列 — 12列对应立春→惊蛰→…→小寒，端午显示甲午而非乙未',
      '流时时辰标签偏移修复 — 子时23-1/丑时1-3/…/亥时21-23正确显示',
      '大运起运天数DST安全化 — Solar.fromDate().subtract()替代裸时间戳',
      'nextDay(1)显式传参 + 空periods防御保护',
    ],
  },
  {
    version: 'V2.4', label: '内测版', date: '2026-06-02', tag: 'ui',
    items: [
      '品牌统一为"卦卦" — 纯黑 + 霓虹绿 + 零圆角设计语言',
      'Hero 着陆页 — 太极 SVG + "开始探索"按钮，点击切换至 App',
      '排盘表单重设计 — 6 行对称布局，磨砂玻璃卡（backdrop-filter）',
      '所有按钮/开关/Pill 组改为直角，粗绿边框',
      '菜单改造 — 顶栏右下 dropdown，覆盖层毛玻璃效果',
      '排盘卡片窄化 — 88% 宽度居中，两侧露出术语雨背景',
      '合盘 UI 重做 — 双卡布局 + pill-group 性别 + 移除名人和今按钮',
      '手机端响应式适配 — 逐级断点 768/600/480/380px',
      '排盘结果区玻璃感强化 + 边框增强',
      '移除暗黑模式、名人 Tab、PDF 导出等废弃功能',
      '起运/交运/零岁金布局优化，移除今按钮',
      '提交规范：每次提交前更新版本号',
    ],
  },
  {
    version: 'V2.3', label: '内测版', date: '2026-06-01', tag: 'fix',
    items: [
      '子时换日修复 — 23:00-23:59 日柱/农历进次日，匹配问真八字',
      '测试流程标准化 — 写入项目记忆，后续测试按固定路径执行',
      '大运计算校验 — 确认未受影响',
    ],
  },
  {
    version: 'V2.2', label: '内测版', date: '2026-05-29', tag: 'feat',
    items: [
      '版本更新历史页面 — 设置 Tab 查看全部版本记录',
      '中文阶段标注 — 内测版/改版/核心/初版，一目了然',
      '彩色类型标签 — 功能/界面/修复，按颜色区分',
      '数据驱动 — version-history.js + settings.js 独立维护',
    ],
  },
  {
    version: 'V2.1', label: '内测版', date: '2026-05-29', tag: 'feat',
    items: [
      '择日月历选中高亮 — 点击日期红色边框圈跟随，当天金色保留',
      '吉凶标签修复 — CDN 版缺接口，改用地支推算十二神',
      '强制版本号规则 — 每次提交前更新版本号',
    ],
  },
  {
    version: 'V2.0', label: '内测版', date: '2026-05-28', tag: 'feat',
    items: [
      '运势文案唯一性 — 同人同天刷新不重复，5种变体轮选',
      '维度窜 bug 修复 — 全局内容仅在综合维度显示',
      '合盘 bug 修复 — 甲方输入框补全 + 可选链防御',
      '死代码清理 — 删除6个未引用函数',
      '响应式布局 — 手机端全面适配',
    ],
  },
  {
    version: 'v4.0', label: '改版', date: '—', tag: 'ui',
    items: [
      'UI 全面重做 — 宣纸、墨色、朱砂、金色设计系统',
      '药丸式 Tab 导航 + 卡片层级统一',
      '深色模式适配 + 响应式优化',
    ],
  },
  {
    version: 'v3.2', label: '扩充', date: '—', tag: 'feat',
    items: [
      '组件重构 — 代码结构优化',
      '称骨算命 + 周趋势图表 + 人生 K 线图',
    ],
  },
  {
    version: 'v3.0', label: '核心', date: '—', tag: 'feat',
    items: [
      '时间轴切换器 — 流年/流月/流日/流时切换',
      '金色色系回归 + 卡片布局重排',
    ],
  },
  {
    version: 'v2', label: '完善', date: '—', tag: 'feat',
    items: [
      '四柱图示 + 运势分析报告 + 古籍引证',
      '胎元/命宫/身宫 + 十二长生 + 人元司令',
      '名人八字库 + 五运六气',
    ],
  },
  {
    version: 'V1.0', label: '初版', date: '—', tag: 'feat',
    items: [
      '基础八字排盘 — 纯前端 SPA',
      '基于 lunar-javascript 引擎',
    ],
  },
];
